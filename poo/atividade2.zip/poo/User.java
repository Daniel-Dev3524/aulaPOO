package poo;

public interface User {
    public String criptografarSenha();
    public Boolean isAdmin();
    public Boolean verificarSenha();
}
